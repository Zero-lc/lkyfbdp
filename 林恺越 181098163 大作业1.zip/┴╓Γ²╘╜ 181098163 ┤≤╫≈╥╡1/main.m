clear;
clc;
load('a1data.mat');
syms x1 x2;
N=1000;
f=0;
for i=1:N
        f=f+(y(i)-x1-x2*x(i))^2;
end
f=f/2*N;
e=10^(2);
x0=[3,4]; 
[k, ender]=steepest(f,x0,e);
disp("the result is:");
disp(ender(:,1));
