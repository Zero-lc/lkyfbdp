#define N 100000000
#define a 0
#define b 10
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "mpi.h"
int main(int argc, char** argv)
{
	int myid, numprocs;
	int i;
    double startwtime,endwtime;
	double local = 0.0,res, dx = (double)(b - a) / N;
	double inte=0.0, x;
	MPI_Init(&argc, &argv);
	MPI_Status status;
	MPI_Comm_rank(MPI_COMM_WORLD, &myid);
	MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
    startwtime=MPI_Wtime();
	for (i = myid; i < N; i = i + numprocs)
	{
		x = a + i * dx + dx / 2;
		local += x * x*dx;

	}
    if(myid!=0)
	{MPI_Send(&local, 1, MPI_DOUBLE, 0, 1, MPI_COMM_WORLD);}

	
	if(myid==0)
	{   inte=local;
		for (int source = 1; source <numprocs; source++)
		{
			MPI_Recv(&res, 1, MPI_DOUBLE, source, 1, MPI_COMM_WORLD, &status);
			inte += res;
		}
        printf("The integal of x*x in region [%d,%d]= %16.15f\n",a, b, inte);
        endwtime=MPI_Wtime();
	    printf("时间=%f\n",endwtime-startwtime);
    }
    
    MPI_Finalize();
}