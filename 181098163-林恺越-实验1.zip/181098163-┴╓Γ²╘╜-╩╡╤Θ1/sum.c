#include "mpi.h"
#include <stdio.h>
#include <math.h>


int main(int argc, char* argv[])
{
	int done=0,n,myid,numproces,i;
	double sqrtsum,sum;
    double startwtime,endwtime;
	MPI_Init(&argc,&argv);
	MPI_Comm_rank(MPI_COMM_WORLD,&myid);
	MPI_Comm_size(MPI_COMM_WORLD,&numproces);
	fflush(stderr);

	if(myid==0)
	{
		printf("输入一个数字：");
		fflush(stdout);
		scanf("%d",&n);
        startwtime=MPI_Wtime();
	}
	MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
	sum=0.0;
	for(i=myid+1;i<=n;i+=numproces)
		sum+=sqrt(i);
	//mypi=sum;
    printf("I am process %d,and SqrtSum=%f.\n",myid,sum);
	MPI_Reduce(&sum,&sqrtsum,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
	if(myid==0)
	{
		printf("结果%.16f\n", sqrtsum);
        endwtime=MPI_Wtime();
	    printf("时间=%f\n",endwtime-startwtime);
	}
		
	
	MPI_Finalize();
	return 0;
}