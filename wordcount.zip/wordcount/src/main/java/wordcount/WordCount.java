import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URI;
import java.util.HashSet;
import java.util.Set;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.Random;
import java.util.StringTokenizer;
import java.io.PrintWriter;
import java.io.DataOutput;  
import java.io.DataInput;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.RecordWriter;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.util.StringUtils;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.map.InverseMapper;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.log4j.Logger;


public class WordCount extends Configured implements Tool {
  private static class CustomFileOutPutFormat extends FileOutputFormat<Text, LongWritable> {
 
    @Override
    public RecordWriter<Text, LongWritable> getRecordWriter(
            TaskAttemptContext job) throws IOException, InterruptedException {
        Path fileDir = FileOutputFormat.getOutputPath(job);
        Path fileName = new Path(fileDir.toString()+"/res.txt");
        LOG.info("------------------------------------- " );
        System.out.println(fileName.getName());
        Configuration conf = job.getConfiguration();
        FSDataOutputStream file = fileName.getFileSystem(conf).create(fileName);
        return new CustomRecordWrite(file);
    }
}
 
private static class CustomRecordWrite extends RecordWriter<Text, LongWritable> {

    
        private PrintWriter write = null;
 
        public CustomRecordWrite(FSDataOutputStream file) {
            this.write = new PrintWriter(file);
        }
 
        @Override
        public void write(Text key, LongWritable value) throws IOException,
                InterruptedException {
            for(int i=1;i<=100;i=i+1)
            {write.println(String.valueOf(i)+" : " + key.toString() + " , "  + value.toString());
                }
            write.close();

        }
 
        @Override
        public void close(TaskAttemptContext context) throws IOException,
                InterruptedException {
            write.close();
        }
    
}

  private static final Logger LOG = Logger.getLogger(WordCount.class);

  public static void main(String[] args) throws Exception {
    int res = ToolRunner.run(new WordCount(), args);
    System.exit(res);
  }
  private static class IntWritableDecreasingComparator extends IntWritable.Comparator {
    public int compare(WritableComparable a, WritableComparable b) {
      return -super.compare(a, b);
    }
    
    public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
        return -super.compare(b1, s1, l1, b2, s2, l2);
    }
    
}
  public int run(String[] args) throws Exception {
    Job job = Job.getInstance(getConf(), "wordcount");
    for (int i = 0; i < args.length; i += 1) {
      if ("-skip".equals(args[i])) {
        job.getConfiguration().setBoolean("wordcount.skip.patterns", true);
        i += 1;
        job.addCacheFile(new Path(args[i]).toUri());
        LOG.info("Added file to the distributed cache: " + args[i]);
      }
    }
    Path tempDir = new Path("wordcount-temp-" + Integer.toString(
                    new Random().nextInt(Integer.MAX_VALUE)));
    Path tempDir1 = new Path("wordcount-temp1-" + Integer.toString(
                    new Random().nextInt(Integer.MAX_VALUE)));
    job.setJarByClass(this.getClass());
    job.setMapperClass(Map.class);
    job.setCombinerClass(Reduce.class);
    job.setReducerClass(Reduce.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, tempDir);
            job.setOutputFormatClass(SequenceFileOutputFormat.class);
            if(job.waitForCompletion(true))
            {
                Job sortJob = Job.getInstance(getConf(), "sort");
                sortJob.setJarByClass(WordCount.class);
                
                FileInputFormat.addInputPath(sortJob, tempDir);
                sortJob.setInputFormatClass(SequenceFileInputFormat.class);
                
                sortJob.setMapperClass(InverseMapper.class);
                sortJob.setNumReduceTasks(1); 
                FileOutputFormat.setOutputPath(sortJob, tempDir1);
                sortJob.setOutputKeyClass(IntWritable.class);
                sortJob.setOutputValueClass(Text.class);
                sortJob.setSortComparatorClass(IntWritableDecreasingComparator.class);
                if(sortJob.waitForCompletion(true))  
               {Job writeJob = Job.getInstance(getConf(), "write");
                writeJob.setJarByClass(WordCount.class);
                
                FileInputFormat.addInputPath(writeJob, tempDir1);
                writeJob.setInputFormatClass(TextInputFormat.class);
                writeJob.setMapperClass(InverseMapper.class);
                writeJob.setNumReduceTasks(0); 
                FileOutputFormat.setOutputPath(writeJob, new Path(args[1]));
                writeJob.setMapOutputKeyClass(Text.class);
                writeJob.setMapOutputValueClass(LongWritable.class);
                //LOG.info("11111111111here0000000000000 " );
                writeJob.setOutputKeyClass(Text.class);
                //LOG.info("000000000000here11111111110 " );
                writeJob.setOutputValueClass(IntWritable.class);
                //LOG.info("000000000000here0000000000000 " );
                writeJob.setOutputFormatClass(CustomFileOutPutFormat.class);
                System.exit(writeJob.waitForCompletion(true) ? 0 : 1);}
                
            }
            //FileSystem.get(getConf()).deleteOnExit(tempDir);
             //FileSystem.get(getConf()).deleteOnExit(tempDir1);
             return 0;
  }

  public static class Map extends Mapper<LongWritable, Text, Text, IntWritable> {
    private final static IntWritable one = new IntWritable(1);
    private Text word = new Text();
    private boolean caseSensitive = false;
    private long numRecords = 0;
    private String input;
    private Set<String> patternsToSkip = new HashSet<String>();
    private static final Pattern WORD_BOUNDARY = Pattern.compile("\\s*\\b\\s*");

    protected void setup(Mapper.Context context)
        throws IOException,
        InterruptedException {
      if (context.getInputSplit() instanceof FileSplit) {
        this.input = ((FileSplit) context.getInputSplit()).getPath().toString();
      } else {
        this.input = context.getInputSplit().toString();
      }
      Configuration config = context.getConfiguration();
      this.caseSensitive = config.getBoolean("wordcount.case.sensitive", false);
      if (config.getBoolean("wordcount.skip.patterns", false)) {
        URI[] localPaths = context.getCacheFiles();
        parseSkipFile(localPaths[0]);
      }
    }

    private void parseSkipFile(URI patternsURI) {
      LOG.info("Added file to the distributed cache: " + patternsURI);
      try {
        BufferedReader fis = new BufferedReader(new FileReader(new File(patternsURI.getPath()).getName()));
        String pattern;
        while ((pattern = fis.readLine()) != null) {
          patternsToSkip.add(pattern);
        }
      } catch (IOException ioe) {
        System.err.println("Caught exception while parsing the cached file '"
            + patternsURI + "' : " + StringUtils.stringifyException(ioe));
      }
    }

    public void map(LongWritable offset, Text lineText, Context context)
        throws IOException, InterruptedException {
      String line = lineText.toString();
      line = line.toLowerCase();
      Text currentWord = new Text();
      for (String word : WORD_BOUNDARY.split(line)) {
        if (word.isEmpty() || patternsToSkip.contains(word)) {
            continue;
        }
            currentWord = new Text(word);
            if(currentWord.getLength() >=3){
            context.write(currentWord,one);
            }
        }             
    }
  }
  public static class Reduce extends Reducer<Text, IntWritable, Text, IntWritable> {
    @Override
    public void reduce(Text word, Iterable<IntWritable> counts, Context context)
        throws IOException, InterruptedException {
      int sum = 0;
      for (IntWritable count : counts) {
        sum += count.get();
      }
      context.write(word, new IntWritable(sum));
    }
  }
}

